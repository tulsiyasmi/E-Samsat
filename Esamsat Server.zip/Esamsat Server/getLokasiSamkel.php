<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from samkel    where YEAR(tanggal) = YEAR(NOW()) AND MONTH(tanggal)
     = MONTH(NOW()) AND DAY(tanggal) = DAY(NOW())  order by nama_uptd;";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
        //echo $data["judul"]." ";

        $item[] = array(
            'nama_uptd'=>$data["nama_uptd"],
            'kecamatan' =>$data["kecamatan"],
            'tanggal' =>$data["tanggal"],
            'jadwal'  =>$data["jadwal"],
            'lokasi'  =>$data["lokasi"]
            
         
         

            
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

    
    

    
?>