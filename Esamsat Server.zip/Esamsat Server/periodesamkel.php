<?php
$konn = mysqli_connect("localhost","root","","esamsat");

$nama_uptd = $_GET['nama_uptd'];
$bulan = $_GET['bulan'];

    $sql ="select * from samkel where MONTH(tanggal) = '$bulan' AND nama_uptd = '$nama_uptd' order by DAY(tanggal)";
    $query = mysqli_query($konn, $sql);

    if(mysqli_num_rows($query) > 0){

        while($data = mysqli_fetch_array($query)){
    
            $item[] = array(
                'nama_uptd'=>$data["nama_uptd"],
                'kecamatan' =>$data["kecamatan"],
                'tanggal' =>$data["tanggal"],
                'jadwal'  =>$data["jadwal"],
                'lokasi'  =>$data["lokasi"]
            );
        }
        $response = array(
            'result'=>$item
        );
        echo json_encode($response);

    }

?> 