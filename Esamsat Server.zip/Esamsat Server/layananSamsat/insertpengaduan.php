<?php
 
if($_SERVER['REQUEST_METHOD']=='POST') {
 
   $response = array();
   //mendapatkan data 
   $id = $_POST['id'];
   $nama = $_POST['nama'];
   $email = $_POST['email'];
   $nomor = $_POST['nomor'];
 
   require_once('koneksi.php');
   //Cek npm sudah terdaftar apa belum
   $sql = "SELECT * FROM user WHERE id ='$id'";
   $check = mysqli_fetch_array(mysqli_query($con,$sql));
   if(isset($check)){
     $response["value"] = 0;
     $response["message"] = "oops! ID sudah terdaftar!";
     echo json_encode($response);
   } else {
     $sql = "INSERT INTO user (id,nama,email,nomor) VALUES('$id','$nama','$email','$nomor')";
     if(mysqli_query($con,$sql)) {
       $response["value"] = 1;
       $response["message"] = "Sukses mendaftar";
       echo json_encode($response);
     } else {
       $response["value"] = 0;
       $response["message"] = "oops! Coba lagi!";
       echo json_encode($response);
     }
   }
   // tutup database
   mysqli_close($con);
} else {
  $response["value"] = 0;
  $response["message"] = "oops! Coba lagi!";
  echo json_encode($response);
}