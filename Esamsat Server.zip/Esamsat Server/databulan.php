<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from periode order by id;";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
      

        $item[] = array(
            'id'  =>$data["id"],
            'bulan'=>$data["bulan"]
            
            
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

    
    

    
?>