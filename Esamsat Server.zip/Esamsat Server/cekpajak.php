<?php
include_once 'connect.php';


 $cek=mysqli_query($konn,"SELECT * FROM tbl_kendaraan");
 $json_reponse = array();
 
 $result=mysqli_num_rows($cek);
 if ($result>0) {
     while ($row=mysqli_fetch_array($cek)){
         $json_reponse[] = $row;
     }
     echo json_encode(array('tbl_kendaraan' => $json_reponse));
     
}
	
	
        
?>