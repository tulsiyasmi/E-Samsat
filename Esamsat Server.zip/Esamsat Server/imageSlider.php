<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from informasi order by id;";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
      

        $item[] = array(
            
            'title'=>$data["title"],
            'image_url'=>$data["image_url"],
            'description'=>$data["description"]
           
            
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

    
    

    
?>