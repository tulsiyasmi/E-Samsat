<?php
$konn = mysqli_connect("localhost","root","","esamsat");

$result = mysqli_query($konn, 
     "CALL LubuksikapingNov") or die("Query fail: " . mysqli_error($konn));

  //loop the result set
  while ($row = mysqli_fetch_array($result)){   
    $item[] = array(
        'nama_uptd'=>$row["nama_uptd"],
        'kecamatan' =>$row["kecamatan"],
        'tanggal' =>$row["tanggal"],
        'jadwal'  =>$row["jadwal"],
        'lokasi'  =>$row["lokasi"]
        
     
     

        
        
    );
}
$response = array(
    'result'=>$item
);
echo json_encode($response);
   
    

    
?>