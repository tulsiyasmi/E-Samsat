<?php 

$konn = mysqli_connect("localhost","root","","esamsat");

if (mysqli_connect_errno()) {
 	echo "koneksi gagal : " . mysqli_connect_error() ;
}

 ?>