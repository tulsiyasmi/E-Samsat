<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from peraturan order by id;";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
        //echo $data["judul"]." ";

        $item[] = array(
            'id'  =>$data["id"],
            'nama'=>$data["nama_peraturan"]
            
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

    
    

    
?>