<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from tbl_kendaraan ; ";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
    

        $item[] = array(
            'NoKendaraan'=>$data["NoKendaraan"],
            'TahunKendaraan' =>$data["TahunKendaraan"],
            'MerkKendaraan' =>$data["MerkKendaraan"],
            'TipeKendaraan'  =>$data["TipeKendaraan"],
            'WarnaKendaraan'  =>$data["WarnaKendaraan"],
            'TglPajak'=>$data["TglPajak"],
            'TglStnk' =>$data["TglStnk"],
            'Status' =>$data["Status"],
            'BiayaPKB'  =>$data["BiayaPKB"],
            'SanksiPKB'  =>$data["SanksiPKB"],
            'BiayaSwdkllj'  =>$data["BiayaSwdkllj"],
            'SanksiSwdkllj'  =>$data["SanksiSwdkllj"],
            'ADMTnkb'  =>$data["ADMTnkb"],
            'ADMStnk'=>$data["ADMStnk"]
        
         
         

            
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

   

    
?>