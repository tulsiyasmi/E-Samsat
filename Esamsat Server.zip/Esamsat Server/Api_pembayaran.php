<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from cara_pembayaran order by id desc;";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
        //echo $data["judul"]." ";

        $item[] = array(
           
            'nama_bank'=>$data["nama_bank"],
            'image' =>$data["image"],
            'detail' =>$data["detail"]

            
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

  
    

    
?>

