<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from uptd order by no_telp ASC;";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
        //echo $data["judul"]." ";

        $item[] = array(
           
            'nama_uptd'=>$data["nama_uptd"],
            'alamat' =>$data["alamat"],
            'no_telp' =>$data["no_telp"]

            
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

  
    

    
?>

