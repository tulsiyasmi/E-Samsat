<?php 
	/* ===== www.dedykuncoro.com ===== */
	include_once "connect.php";

	$NoKendaraan = $_POST['Nokendaraan'];

	$query = mysqli_query($konn, "SELECT * FROM tbl_kendaraan WHERE NoKendaraan LIKE '%".$NoKendaraan."%'");

	$num_rows = mysqli_num_rows($query);

	if ($num_rows > 0){
		$json = '{"value":1, "results": [';

		while ($row = mysqli_fetch_array($query)){
			$char ='"';

			$json .= '{
				"NoKendaraan": "'.str_replace($char,'`',strip_tags($row['NoKendaraan'])).'",
				"TahunKendaraan": "'.str_replace($char,'`',strip_tags($row['TahunKendaraan'])).'"
                "MerkKendaraan": "'.str_replace($char,'`',strip_tags($row['MerkKendaraan'])).'"
                "TipeKendaraan": "'.str_replace($char,'`',strip_tags($row['TipeKendaraan'])).'"
                "WarnaKendaraan": "'.str_replace($char,'`',strip_tags($row['WarnaKendaraan'])).'"
                "TglPajak": "'.str_replace($char,'`',strip_tags($row['TglPajak'])).'"
                "TglStnk": "'.str_replace($char,'`',strip_tags($row['TglStnk'])).'"
                "Status": "'.str_replace($char,'`',strip_tags($row['Status'])).'"
                "BiayaPKB": "'.str_replace($char,'`',strip_tags($row['BiayaPKB'])).'"
                "SanksiPKB": "'.str_replace($char,'`',strip_tags($row['SanksiPKB'])).'"
                "BiayaSwdkllj": "'.str_replace($char,'`',strip_tags($row['BiayaSwdkllj'])).'"
                "SanksiSwdkllj": "'.str_replace($char,'`',strip_tags($row['SanksiSwdkllj'])).'"
                "ADMTnkb": "'.str_replace($char,'`',strip_tags($row['ADMTnkb'])).'"
                "ADMStnk": "'.str_replace($char,'`',strip_tags($row['ADMStnk'])).'"
				"Total": "'.str_replace($char,'`',strip_tags($row['Total'])).'"
                
b 
			},';
		}

		$json = substr($json,0,strlen($json)-1);  

		$json .= ']}';

	} else {
		$json = '{"value":0, "message": "Data tidak ditemukan."}';
	}

	echo $json;

	mysqli_close($konn);
?>