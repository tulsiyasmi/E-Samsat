<?php
$konn = mysqli_connect("localhost","root","","esamsat");


    $sql =" select * from layanan_samsat order by id;";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
        //echo $data["judul"]." ";

        $item[] = array(
           
            'nama_layanan'=>$data["nama_layanan"],
            'url_file' =>$data["url_file"]
            
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

  
    

    
?>

