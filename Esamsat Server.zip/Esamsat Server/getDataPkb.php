<?php
$konn = mysqli_connect("localhost","root","","esamsat");

$nokendara = $_GET['noKendara'];

    $sql =" select * from tbl_kendaraan where NoKendaraan = '$nokendara' ";
    $query = mysqli_query($konn, $sql);
    while($data = mysqli_fetch_array($query)){
    

        $item[] = array(
            'noKendaraan'=>$data["NoKendaraan"],
           'tahunKendarb aan' =>$data["TahunKendaraan"],
            'merkKendaraan' =>$data["MerkKendaraan"],
            'tipeKendaraan'  =>$data["TipeKendaraan"],
            'warnaKendaraan'  =>$data["WarnaKendaraan"],
            'tglPajak'=>$data["TglPajak"],
            'tglStnk' =>$data["TglStnk"],
            'status' =>$data["StatusKendaraan"],  
            'biayaPKB'  =>$data["BiayaPKB"],
            'sanksiPKB'  =>$data["SanksiPKB"],
            'biayaSwdkllj'  =>$data["BiayaSwdkllj"],
            'sanksiSwdkllj'  =>$data["SanksiSwdkllj"],
            'aDMTnkb'  =>$data["ADMTnkb"],
            'aDMStnk'=>$data["ADMStnk"],
            'tOtal'=>$data["Total"]
        
        );
    }
    $response = array(
        'result'=>$item
    );
    echo json_encode($response);

   

    
?>